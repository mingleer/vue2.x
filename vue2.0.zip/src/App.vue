<template>
    <div class="app" id="app" onselectstart="return false;">
        <router-view />
    </div>
</template>

<script>
export default {
    name: 'App'
};
</script>
