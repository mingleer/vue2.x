<template>
    <section class="">home</section>
</template>

<script>
export default {
    name: '',
    components: {},
    props: {},
    data() {
        return {};
    },
    computed: {},
    watch: {},
    created() {
        this.createdInitEvent();
    },
    mounted() {
        this.mountedInitEvent();
    },
    destroyed() {},
    methods: {
        createdInitEvent() {},
        mountedInitEvent() {}
    }
};
</script>

<style lang="less" scoped></style>
