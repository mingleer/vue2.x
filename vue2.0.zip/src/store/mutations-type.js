export const SET_LANG = 'SET_LANG'; // 国际化
export const SET_MENU_COLLAPSED = 'SET_MENU_COLLAPSED'; // 主菜单菜单合并
