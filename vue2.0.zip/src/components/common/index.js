import loading from './loading';
import alert from './alert';

export default {
    loading,
    alert
};

export {
    loading,
    alert
};
