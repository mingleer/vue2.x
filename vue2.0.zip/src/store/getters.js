export const getLang = state => state.lang;
export const getIsCollapsed = state => state.isCollapsed;
